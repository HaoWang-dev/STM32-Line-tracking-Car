#ifndef PID_H_
#define PID_H_


#include <math.h>


//限幅
#define LIMIT(x, min, max) (x)=(((x)<=(min))?(min):(((x)>=(max))?(max):(x)))

//定义名为PID的结构体类型
typedef struct
{
	float kp, ki, kd;
	float P, I, D;								//P项、I项、D项
	float error, lastError, beforelastError;	//误差、上次误差、上上次误差
	float integral, maxIntegral;				//积分、积分限幅
	float output, maxOutput;					//输出、输出限幅

	// 非线性比例项参数
	float ap;	 //kp的基础值
	float bp;	 //kp的动态增量幅度
	float cp; 	 //误差变化的速率系数

	// 非线性积分项参数
	float ai; 	 //积分增益的基础值
	float ci;	 //积分增益衰减系数
	float k0;    //小误差区Ki0衰减系数
	float k1;  	 //Ki0 外壳函数
	float e0;    //Ki0 切换阈值
}PID;


//定义名为CascadePID的结构体类型
typedef struct
{
	PID inner;		//内环
	PID outer;		//外环
	float output;	//串级输出，等于inner.output
}CascadePID;


//PID参数初始化函数（PID的指针， kp， ki， kd， 积分上限， 输出上限）
void PID_Init(PID* pid, float p, float i, float d, float maxI, float maxOut);

//PID输出参数初始化函数（PID的指针， 输出值）
void PID_Init_Output(PID* pid, float output);

//清空一个PID的历史数据（PID的指针）
void PID_Clear(PID* pid);


//单级位置式PID算法(PID的指针， 目标值， 当前值)
void PID_Single_Calc(PID* pid, float reference, float feedback);

//单级位置式PID算法(PID的指针， 误差)
void PID_Single_err(PID* pid, float err);


//单级增量式PID算法(PID的指针， 目标值， 当前值)
void PID_Incremental_Calc(PID* pid, float reference, float feedback);

//单级增量式PID算法(PID的指针， 误差)
void PID_Incremental_err(PID* pid, float err);


//单级增量式PI算法，控制电机速度，输入(PID的指针， 当前速度， 目标速度)，返回PWM波
void Incremental_PI (PID* pid, float Encoder, int Target);


//单级位置式PID算法（PID的指针， 目标值， 当前值， 滤波权重），加入低通滤波器，减少噪声干扰
void PID_Single_Calc_Improve_Filtering(PID* pid, float reference, float feedback, float weight);

//单级位置式PID算法（PID的指针， 目标值， 当前值， 误差阈值， 输出零点， 输出偏移），加入输入死区和输出偏移，应对误差小时启动力度不够，输入的目标值或实际值有微小的噪声波动
void PID_Single_Calc_Improve_IOput(PID* pid, float reference, float feedback, float Error_Edge, float Output_Edge, float Offset);


//串级PID计算（PID的指针， 外环目标值， 外环实际值， 内环实际值）
void PID_Cascade_Calc(CascadePID *pid, float angleRef, float angleFdb, float speedFdb);


//变结构体PID初始化函数
void PID_VSInit(PID *pid, float _ap, float _bp, float _cp, float _ai, float _ci, float _k0, float _k1, float _e0, float maxI, float maxOut);

//变结构PID（PID的指针， 误差）
void PID_VariableStructure(PID *pid, float err);


#endif /* PID_H_ */
