#include "pid.h"


//PID参数初始化函数（PID的指针， kp， ki， kd， 积分上限， 输出上限）
void PID_Init(PID* pid, float p, float i, float d, float maxI, float maxOut)
{
	pid->kp = p;
	pid->ki = i;
	pid->kd = d;
	pid->maxIntegral = maxI;
	pid->maxOutput = maxOut;
}


//PID输出参数初始化函数（PID的指针， 输出值）
void PID_Init_Output(PID* pid, float output)
{
	pid->output=output;
}


//清空一个PID的历史数据（PID的指针）
void PID_Clear(PID* pid)
{
	pid->error = 0;				//误差
	pid->lastError = 0;			//上次误差
	pid->beforelastError = 0;	//上上次误差
	pid->P = 0;					//比例项
	pid->I = 0;					//积分项
	pid->D = 0;					//微分项
	pid->integral = 0;			//积分
	pid->output = 0;			//输出
}


//单级位置式PID算法(PID的指针， 目标值， 当前值)
void PID_Single_Calc(PID* pid, float reference, float feedback)
{
	//更新数据
	pid->lastError = pid->error;
	pid->error = reference - feedback;
	//计算微分
	pid->D = (pid->error - pid->lastError) * pid->kd;
	//计算比例
	pid->P = pid->error * pid->kp;
	//计算积分
	pid->integral += pid->error * pid->ki;
	//积分限幅
	LIMIT(pid->integral, -pid->maxIntegral, pid->maxIntegral);
	pid->I = pid->integral;
	//计算输出
	pid->output = pid->P + pid->I + pid->D;
	//输出限幅
	LIMIT(pid->output, -pid->maxOutput, pid->maxOutput);
}


//单级位置式PID算法(PID的指针， 误差)
void PID_Single_err(PID* pid, float err)
{
	//更新数据
	pid->lastError = pid->error;
	pid->error = err;
	//计算微分
	pid->D = (pid->error-pid->lastError) * pid->kd;
	//计算比例
	pid->P = pid->error * pid->kp;
	//计算积分
	pid->integral += pid->error * pid->ki;
	//积分限幅
	LIMIT(pid->integral, -pid->maxIntegral, pid->maxIntegral);
	pid->I = pid->integral;
	//计算输出
	pid->output = pid->P + pid->I + pid->D;
	//输出限幅
	LIMIT(pid->output, -pid->maxOutput, pid->maxOutput);
}


//单级增量式PID算法(PID的指针， 目标值， 当前值)
void PID_Incremental_Calc(PID* pid, float reference, float feedback)
{
	//更新数据
	pid->beforelastError = pid->lastError;
	pid->lastError = pid->error;
	pid->error = reference - feedback;
	//计算P项
	pid->P = (pid->error - pid->lastError) * pid->kp;
	//计算I项
	pid->I = pid->error * pid->ki;
	//计算D项
	pid->D = (pid->error - 2 * pid->lastError + pid->beforelastError) * pid->kd;
	//计算输出
	pid->output += pid->P + pid->I + pid->D;
	//输出限幅
	LIMIT(pid->output, -pid->maxOutput, pid->maxOutput);
}


//单级增量式PID算法(PID的指针， 误差)
void PID_Incremental_err(PID* pid, float err)
{
	//更新数据
	pid->beforelastError = pid->lastError;
	pid->lastError = pid->error;
	pid->error = err;
	//计算P项
	pid->P = (pid->error - pid->lastError) * pid->kp;
	//计算I项
	pid->I = pid->error * pid->ki;
	//计算D项
	pid->D = (pid->error - 2 * pid->lastError + pid->beforelastError) * pid->kd;
	//计算输出
	pid->output += pid->P + pid->I + pid->D;
	//输出限幅
	LIMIT(pid->output, -pid->maxOutput, pid->maxOutput);
}


//单级增量式PI算法，控制电机速度，输入(当前速度，目标速度)，返回PWM波
void Incremental_PI (PID* pid, float Encoder, int Target)
{
   pid->error = Target - Encoder;                                  					//计算误差
   pid->output += pid->kp * (pid->error - pid->lastError) + pid->ki * pid->error;   //增量式PI控制器
   pid->lastError = pid->error;														//保存上一次误差
}


/* 以下是PID位置式算法的改进版本 */


//单级位置式PID算法（PID的指针， 目标值， 当前值， 滤波权重），加入低通滤波器，减少噪声干扰
void PID_Single_Calc_Improve_Filtering(PID* pid, float reference, float feedback, float weight)
{
	//更新数据
	pid->lastError = pid->error;
	pid->error = reference - feedback;
	//计算微分，加入滤波
	pid->D = (1 - weight) * (pid->error - pid->lastError) * pid->kd + weight * pid->D;
	//计算比例
	pid->P = pid->error * pid->kp;
	//计算积分
	pid->integral += pid->error * pid->ki;
	//积分限幅
	LIMIT(pid->integral, -pid->maxIntegral, pid->maxIntegral);
	pid->I = pid->integral;
	//计算输出
	pid->output = pid->P + pid->I + pid->D;
	//输出限幅
	LIMIT(pid->output, -pid->maxOutput, pid->maxOutput);
}


//单级位置式PID算法（PID的指针， 目标值， 当前值， 误差阈值， 输出零点， 输出偏移），加入输入死区和输出偏移，应对误差小时启动力度不够，输入的目标值或实际值有微小的噪声波动
void PID_Single_Calc_Improve_IOput(PID* pid, float reference, float feedback, float Error_Edge, float Output_Edge, float Offset)
{
	//更新数据
	pid->lastError = pid->error;
	pid->error = reference - feedback;
	//输入阈值判断
	if(fabsf(pid->error) < Error_Edge)
	{
		pid->output = 0;
	}
	else
	{
		//计算微分
		pid->D = (pid->error - pid->lastError) * pid->kd;
		//计算比例
		pid->P = pid->error * pid->kp;
		//计算积分
		pid->integral += pid->error * pid->ki;
		//积分限幅
		LIMIT(pid->integral, -pid->maxIntegral, pid->maxIntegral);
		pid->I = pid->integral;
		//计算输出
		pid->output = pid->P + pid->I + pid->D;
		if(pid->output < -Output_Edge)
		{
			pid->output -= Offset;
		}
		else if(pid->output > Output_Edge)
		{
			pid->output += Offset;
		}
		else
		{
			pid->output = 0;
		}
		//输出限幅
		LIMIT(pid->output, -pid->maxOutput, pid->maxOutput);
	}
}


//串级PID计算
void PID_Cascade_Calc(CascadePID *pid, float angleRef, float angleFdb, float speedFdb)
{
	PID_Single_Calc(&pid->outer, angleRef, angleFdb);		  //计算外环(角度环)
	PID_Single_Calc(&pid->inner, pid->outer.output, speedFdb);//计算内环(速度环)
	pid->output = pid->inner.output;						  //内环输出就是串级PID的输出
}


//变结构体PID初始化函数
void PID_VSInit(PID *pid, float _ap, float _bp, float _cp, float _ai, float _ci, float _k0, float _k1, float _e0, float maxI, float maxOut)
{
    pid->ap = _ap;
    pid->bp = _bp;
    pid->cp = _cp;
    pid->ai = _ai;
    pid->ci = _ci;
    pid->k0 = _k0;
    pid->k1 = _k1;
    pid->e0 = _e0;

    pid->maxIntegral = maxI;
    pid->maxOutput = maxOut;
}


// 变结构PID
void PID_VariableStructure(PID *pid, float err)
{
	//更新误差
	pid->lastError = pid->error;
	pid->error = err;
	//定义误差的绝对值
	float absErr = fabsf(err);

	/*====== 比例项计算 ======*/
	//动态比例增益 Kp(e) = ap + bp * (1 - exp(-cp * |e|))
	float Kp_dynamic = pid->ap + pid->bp * (1.0f - expf(-pid->cp * absErr));
	float proportional = Kp_dynamic * err;

	/*====== 积分项计算 ======*/
	//I项外壳函数 Ki0(error)
	float Ki0;
	if (absErr <= pid->e0)
	{
		Ki0 = pid->k1 * expf(-pid->k0 * absErr);
	}
	else
	{
		Ki0 = 1.0f;
	}
	//动态积分增益 Ki(e) = Ki0(error) * ai * exp(-ci * |e|)
	float Ki_dynamic = Ki0 * pid->ai * expf(-pid->ci * absErr);
	//积分累加
	pid->integral +=  Ki_dynamic * err;
	//积分限幅
	LIMIT(pid->integral, -pid->maxIntegral, pid->maxIntegral);
	//最终输出
	pid->output = proportional + pid->integral;
	//输出限幅
	LIMIT(pid->output, -pid->maxOutput, pid->maxOutput);
}


