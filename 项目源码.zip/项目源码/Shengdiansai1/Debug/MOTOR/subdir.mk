################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../MOTOR/motor.c 

OBJS += \
./MOTOR/motor.o 

C_DEPS += \
./MOTOR/motor.d 


# Each subdirectory must supply rules for building sources it contributes
MOTOR/%.o MOTOR/%.su MOTOR/%.cyclo: ../MOTOR/%.c MOTOR/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../DELAY -I../ENCODER -I../GW -I../JY61P -I../MOTOR -I../OLED -I../PID -I../LED -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-MOTOR

clean-MOTOR:
	-$(RM) ./MOTOR/motor.cyclo ./MOTOR/motor.d ./MOTOR/motor.o ./MOTOR/motor.su

.PHONY: clean-MOTOR

