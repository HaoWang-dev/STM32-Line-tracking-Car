################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../JY61P/jy61p.c 

OBJS += \
./JY61P/jy61p.o 

C_DEPS += \
./JY61P/jy61p.d 


# Each subdirectory must supply rules for building sources it contributes
JY61P/%.o JY61P/%.su JY61P/%.cyclo: ../JY61P/%.c JY61P/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F407xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I../DELAY -I../ENCODER -I../GW -I../JY61P -I../MOTOR -I../OLED -I../PID -I../LED -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-JY61P

clean-JY61P:
	-$(RM) ./JY61P/jy61p.cyclo ./JY61P/jy61p.d ./JY61P/jy61p.o ./JY61P/jy61p.su

.PHONY: clean-JY61P

