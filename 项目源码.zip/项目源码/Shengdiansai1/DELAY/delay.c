#include "delay.h"


void delay_us(uint16_t _usTime)
{
	__HAL_TIM_SetCounter(&DELAY_TIM_HANDLE,0);
	__HAL_TIM_ENABLE(&DELAY_TIM_HANDLE);
	while(__HAL_TIM_GetCounter(&DELAY_TIM_HANDLE) < _usTime);
	__HAL_TIM_DISABLE(&DELAY_TIM_HANDLE);
}


void delay_ms(uint16_t _msTime)
{
	delay_us(_msTime * 1000);
}
