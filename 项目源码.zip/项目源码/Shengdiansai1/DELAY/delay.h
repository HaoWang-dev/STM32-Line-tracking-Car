#ifndef DELAY_H_
#define DELAY_H_

#include "stm32f4xx.h"
#include "tim.h"

#define		DELAY_TIM_HANDLE	htim6

void delay_us(uint16_t _usTime);		//定义一个微秒级定时函数delay_us
void delay_ms(uint16_t _msTime);		//定义一个毫秒级定时函数delay_ms


#endif /* DELAY_H_ */
