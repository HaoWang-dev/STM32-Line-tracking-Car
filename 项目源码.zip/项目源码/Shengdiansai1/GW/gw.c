#include "gw.h"

#ifdef	__PARALLEL__

uint8_t scan_gpio_pin_Parallel()//并行读取感为数据
{
	uint8_t Parallel = 0;

	Parallel |= (HAL_GPIO_ReadPin(GW1_GPIO_Port, GW1_Pin) << 7);
	Parallel |= (HAL_GPIO_ReadPin(GW2_GPIO_Port, GW2_Pin) << 6);
	Parallel |= (HAL_GPIO_ReadPin(GW3_GPIO_Port, GW3_Pin) << 5);
	Parallel |= (HAL_GPIO_ReadPin(GW4_GPIO_Port, GW4_Pin) << 4);
	Parallel |= (HAL_GPIO_ReadPin(GW5_GPIO_Port, GW5_Pin) << 3);
	Parallel |= (HAL_GPIO_ReadPin(GW6_GPIO_Port, GW6_Pin) << 2);
	Parallel |= (HAL_GPIO_ReadPin(GW7_GPIO_Port, GW7_Pin) << 1);
	Parallel |= (HAL_GPIO_ReadPin(GW8_GPIO_Port, GW8_Pin) << 0);

	return Parallel;
}

float calc_error(char Data[8], int8_t weight[8])
{
    int32_t sum_weight = 0;
    int32_t active_count = 0;

    for (uint8_t i = 0; i < 8; i++)
    {
        if (Data[i] == '0')
        {
            sum_weight += weight[i];
            active_count++;
        }
    }
    if (active_count == 0)
    {
        return -75;
    }

    return sum_weight;
}

#endif

#ifdef	__SERIAL__
uint8_t scan_gpio_pin_Serial()//串行读取感为数据
{
	uint8_t Serial = 0;
	char gw_str_Serial[9];

	for(int i = 0; i < 8; i++)
	{
		HAL_GPIO_WritePin(GW_CLK_GPIO_Port, GW_CLK_Pin, GPIO_PIN_RESET);
		Serial |= (HAL_GPIO_ReadPin(GW_DAT_GPIO_Port, GW_DAT_Pin) << (7 - i));
		HAL_GPIO_WritePin(GW_CLK_GPIO_Port, GW_CLK_Pin, GPIO_PIN_SET);
		delay_us(10);
	}//读取数据

	for(int i = 0; i < 8; i++)
	{
		gw_str_Serial[i] = (Serial & (1 << (7-i))) ? '1' : '0';
	}
	gw_str_Serial[8] = '\0';

	OLED_ShowString(0, 20, gw_str_Serial, 6);
	OLED_Update();

	return Serial;
}

#endif
