#ifndef GW_H_
#define GW_H_

#include "stm32f4xx_hal.h"
#include <main.h>
#include "delay.h"
#include "OLED.h"

// 选择并行读取模式
#define	__PARALLEL__

uint8_t scan_gpio_pin_Parallel();//并行读取感为数据
uint8_t scan_gpio_pin_Serial();//串行读取感为数据
//转向环
float calc_error(char Data[8], int8_t weight[8]);

#endif /* GW_H_ */
