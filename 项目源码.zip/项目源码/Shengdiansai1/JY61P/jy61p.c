#include "jy61p.h"

static Gyro_Struct Gyro_Structure;

void jy61pInit(void)
{

	/*================Z轴归零==================*/

	// 寄存器解锁
	uint8_t unlock_reg1[2] = {0x88,0xB5};
	writeDataJy61p(IIC_ADDR,UN_REG,unlock_reg1,2);
	HAL_Delay(200);
	// Z轴归零
	uint8_t z_axis_reg[2] = {0x04,0x00};
	writeDataJy61p(IIC_ADDR,ANGLE_REFER_REG,z_axis_reg,2);
	HAL_Delay(200);
	// 保存
	uint8_t save_reg1[2] = {0x00,0x00};
	writeDataJy61p(IIC_ADDR,SAVE_REG,save_reg1,2);
	HAL_Delay(200);

	/*================角度归零==================*/

	// 寄存器解锁
	uint8_t unlock_reg[2] = {0x88,0xB5};
	writeDataJy61p(IIC_ADDR,UN_REG,unlock_reg,2);
	HAL_Delay(200);
	// 角度归零
	uint8_t angle_reg[2] = {0x08,0x00};
	writeDataJy61p(IIC_ADDR,ANGLE_REFER_REG,angle_reg,2);
	HAL_Delay(200);
	// 保存
	uint8_t save_reg[2] = {0x00,0x00};
	writeDataJy61p(IIC_ADDR,SAVE_REG,save_reg,2);
	HAL_Delay(200);

	// 清空结构体
	memset((void *)&Gyro_Structure,0,sizeof(Gyro_Structure));

}



/******************************************************************
 * 函 数 名 称：IIC_Start
 * 函 数 说 明：IIC起始时序
 * 函 数 形 参：无
 * 函 数 返 回：无
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void IIC_Start(void)
{
        SDA_OUT();

        SCL(0);
        SDA(1);
        SCL(1);

        delay_us(5);

        SDA(0);
        delay_us(5);
        SCL(0);
        delay_us(5);


}
/******************************************************************
 * 函 数 名 称：IIC_Stop
 * 函 数 说 明：IIC停止信号
 * 函 数 形 参：无
 * 函 数 返 回：无
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void IIC_Stop(void)
{
        SDA_OUT();
        SCL(0);
        SDA(0);

        SCL(1);
        delay_us(5);
        SDA(1);
        delay_us(5);

}

/******************************************************************
 * 函 数 名 称：IIC_Send_Ack
 * 函 数 说 明：主机发送应答或者非应答信号
 * 函 数 形 参：0发送应答  1发送非应答
 * 函 数 返 回：无
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void IIC_Send_Ack(unsigned char ack)
{
        SDA_OUT();
        SCL(0);
        SDA(0);
        delay_us(5);
        if(!ack) SDA(0);
        else     SDA(1);
        SCL(1);
        delay_us(5);
        SCL(0);
        SDA(1);
}


/******************************************************************
 * 函 数 名 称：I2C_WaitAck
 * 函 数 说 明：等待从机应答
 * 函 数 形 参：无
 * 函 数 返 回：0有应答  1超时无应答
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
unsigned char I2C_WaitAck(void)
{

        char ack = 0;
        char ack_flag = 50;

        SDA_IN();

        SDA(1);
        while( (SDA_GET()==1) && ( ack_flag ) )
        {
                ack_flag--;
                delay_us(5);
        }

        if( ack_flag == 0 )
        {
                IIC_Stop();
                return 1;
        }
        else
        {
				SCL(1);
				delay_us(5);
                SCL(0);
                SDA_OUT();
        }
        return ack;
}

/******************************************************************
 * 函 数 名 称：Send_Byte
 * 函 数 说 明：写入一个字节
 * 函 数 形 参：dat要写人的数据
 * 函 数 返 回：无
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void Send_Byte(uint8_t dat)
{
	int i = 0;
	SDA_OUT();
	SCL(0);//拉低时钟开始数据传输

	for( i = 0; i < 8; i++ )
	{
		SDA( (dat & 0x80) >> 7 );
		delay_us(2);

		SCL(1);
		delay_us(5);

		SCL(0);
		delay_us(5);

		dat<<=1;
	}
}

/******************************************************************
 * 函 数 名 称：Read_Byte
 * 函 数 说 明：IIC读时序
 * 函 数 形 参：无
 * 函 数 返 回：读到的数据
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
unsigned char Read_Byte(void)
{
    unsigned char i,receive=0;
    SDA_IN();//SDA设置为输入
    for(i=0;i<8;i++ )
    {
        SCL(0);
        delay_us(5);
        SCL(1);
        delay_us(5);
        receive<<=1;
        if( SDA_GET() )
        {
            receive|=1;
        }
        delay_us(5);
    }

    return receive;
}

/******************************************************************
 * 函 数 名 称：writeDataJy61p
 * 函 数 说 明：写数据
 * 函 数 形 参：dev 设备地址
				reg 寄存器地址
				data 数据首地址
				length 数据长度
 * 函 数 返 回：返回0则写入成功
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
uint8_t writeDataJy61p(uint8_t dev, uint8_t reg, uint8_t* data, uint32_t length)
{
    uint32_t count = 0;

    IIC_Start();

    Send_Byte(dev<<1);
    if(I2C_WaitAck() == 1)return 0;

    Send_Byte(reg);
    if(I2C_WaitAck() == 1)return 0;

    for(count=0; count<length; count++)
    {
        Send_Byte(data[count]);
        if(I2C_WaitAck() == 1)return 0;
    }

    IIC_Stop();

    return 1;
}

/******************************************************************
 * 函 数 名 称：readDataJy61p
 * 函 数 说 明：读数据数据
 * 函 数 形 参：dev 设备地址
				reg 寄存器地址
				data 数据存储地址
				length 数据长度
 * 函 数 返 回：返回0则写入成功
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
uint8_t readDataJy61p(uint8_t dev, uint8_t reg, uint8_t *data, uint32_t length)
{
    uint32_t count = 0;

    IIC_Start();

    Send_Byte((dev<<1)|0);
    if(I2C_WaitAck() == 1)return 0;

    Send_Byte(reg);
    if(I2C_WaitAck() == 1)return 0;

	delay_us(5);

    IIC_Start();

    Send_Byte((dev<<1)|1);
    if(I2C_WaitAck() == 1)return 0;

    for(count=0; count<length; count++)
    {
        if(count!=length-1)
		{
			data[count]=Read_Byte();
			IIC_Send_Ack(0);
		}
        else
		{
			data[count]=Read_Byte();
			IIC_Send_Ack(1);
		}

    }

    IIC_Stop();

    return 1;
}

// /******************************************************************
//  * 函 数 名 称：writeDataJy61p
//  * 函 数 说 明：写数据
//  * 函 数 形 参：dev 设备地址
// 				reg 寄存器地址
// 				data 数据首地址
// 				length 数据长度
//  * 函 数 返 回：返回0则写入成功
//  * 作       者：LCKFB
//  * 备       注：无
// ******************************************************************/
// uint8_t writeDataJy61p(uint8_t dev, uint8_t reg, uint8_t* data, uint32_t length)
// {
//	 uint8_t buffer[length + 1];
//	 buffer[0] = reg;
//	 for (uint16_t i = 0; i < length; i++)
//	 {
//		 buffer[i + 1] = data[i];
//	 }
//	 if (HAL_I2C_Master_Transmit(&hi2c3, (dev << 1)|0, buffer, length + 1, 0x100) != HAL_OK) return 0;
//	 else return 1;
// }
//
// /******************************************************************
//  * 函 数 名 称：readDataJy61p
//  * 函 数 说 明：读数据数据
//  * 函 数 形 参：dev 设备地址
// 				reg 寄存器地址
// 				data 数据存储地址
// 				length 数据长度
//  * 函 数 返 回：返回0则写入成功
//  * 作       者：LCKFB
//  * 备       注：无
// ******************************************************************/
// uint8_t readDataJy61p(uint8_t dev, uint8_t reg, uint8_t *data, uint32_t length)
// {
//	 HAL_I2C_Master_Transmit(&hi2c3, (dev<<1)|0 , &reg, 1, 0x100);
//
//     return HAL_I2C_Master_Receive(&hi2c3, (dev<<1)|1, data, length, 0x100);
// }

/******************************************************************
 * 函 数 名 称：get_angle
 * 函 数 说 明：读角度数据
 * 函 数 形 参：无
 * 函 数 返 回：返回结构体
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void get_angle(Gyro_Struct* Data)
{
	// 数据缓存
	uint8_t sda_angle[6] = {0};

	int ret = 0;

	// 清空数据缓存
	memset((void *)sda_angle,0,sizeof(sda_angle));

	// 读取寄存器数据
	ret	= readDataJy61p(IIC_ADDR,0x3D,sda_angle,6);

	 if(ret == 0)
	 {
	 	// 读取失败
	 }

//	#if GYRO_DEBUG
//
//	lc_printf("RollL = %x\r\n",sda_angle[0]);
//	lc_printf("RollH = %x\r\n",sda_angle[1]);
//	lc_printf("PitchL = %x\r\n",sda_angle[2]);
//	lc_printf("PitchH = %x\r\n",sda_angle[3]);
//	lc_printf("YawL = %x\r\n",sda_angle[4]);
//	lc_printf("YawH = %x\r\n",sda_angle[5]);
//
//	#endif

    // 计算 RollX, PitchY 和 YawZ 并确保它们在 -180 到 180 的范围内
    float RollX = (float)(((sda_angle[1] << 8) | sda_angle[0]) / 32768.0 * 180.0);
    if (RollX > 180.0)
    {
        RollX -= 360.0;
    }
    else if (RollX < -180.0)
    {
        RollX += 360.0;
    }

    float PitchY = (float)(((sda_angle[3] << 8) | sda_angle[2]) / 32768.0 * 180.0);
    if (PitchY > 180.0)
    {
        PitchY -= 360.0;
    }
    else if (PitchY < -180.0)
    {
        PitchY += 360.0;
    }

    float YawZ = (float)(((sda_angle[5] << 8) | sda_angle[4]) / 32768.0 * 180.0);
    if (YawZ > 180.0)
    {
        YawZ -= 360.0;
    }
    else if (YawZ < -180.0)
    {
        YawZ += 360.0;
    }

    // 将计算结果保存到结构体中
    Data->x = RollX;
    Data->y = PitchY;
    Data->z = YawZ;
}

/******************************************************************
 * 函 数 名 称：get_acc
 * 函 数 说 明：读加速度数据
 * 函 数 形 参：无
 * 函 数 返 回：返回结构体
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void get_acc(Gyro_Struct* Data)
{
	// 数据缓存
	uint8_t sda_acc[6] = {0};

	int ret = 0;

	// 清空数据缓存
	memset((void *)sda_acc,0,sizeof(sda_acc));

	// 读取寄存器数据
	ret	= readDataJy61p(IIC_ADDR,0x34,sda_acc,6);

	if(ret == 0)
	{
		// 读取失败
	}

//	#if GYRO_DEBUG
//
//	lc_printf("AXL = %x\r\n",sda_acc[0]);
//	lc_printf("AXH = %x\r\n",sda_acc[1]);
//	lc_printf("AYL = %x\r\n",sda_acc[2]);
//	lc_printf("AYH = %x\r\n",sda_acc[3]);
//	lc_printf("AZL = %x\r\n",sda_acc[4]);
//	lc_printf("AZH = %x\r\n",sda_acc[5]);
//
//	#endif

    // 计算 AX, AY 和 AZ
    float AX = (float)(((sda_acc[1] << 8) | sda_acc[0]) / 32768.0f * 16.0f);
    if (AX > 16.0)
    {
        AX -= 32.0;
    }
    else if (AX < -16.0)
    {
        AX += 32.0;
    }
    float AY = (float)(((sda_acc[3] << 8) | sda_acc[2]) / 32768.0f * 16.0f);
    if (AY > 16.0)
    {
        AY -= 32.0;
    }
    else if (AY < -16.0)
    {
        AY += 32.0;
    }
    float AZ = (float)(((sda_acc[5] << 8) | sda_acc[4]) / 32768.0f * 16.0f);
    if (AZ > 16.0)
    {
        AZ -= 32.0;
    }
    else if (AZ < -16.0)
    {
        AZ += 32.0;
    }

    // 将计算结果保存到结构体中
    Data->ax = AX;
    Data->ay = AY;
    Data->az = AZ;
}

/******************************************************************
 * 函 数 名 get_gyro
 * 函 数 说 明：读角加速度数据
 * 函 数 形 参：无
 * 函 数 返 回：返回结构体
 * 作       者：LCKFB
 * 备       注：无
******************************************************************/
void get_gyro(Gyro_Struct* Data)
{
	// 数据缓存
	uint8_t sda_gyro[6] = {0};

	int ret = 0;

	// 清空数据缓存
	memset((void *)sda_gyro,0,sizeof(sda_gyro));

	// 读取寄存器数据
	ret	= readDataJy61p(IIC_ADDR,0x37,sda_gyro,6);

	if(ret == 0)
	{
		// 读取失败
	}

//	#if GYRO_DEBUG
//
//	lc_printf("GXL = %x\r\n",sda_gyro[0]);
//	lc_printf("GXH = %x\r\n",sda_gyro[1]);
//	lc_printf("GYL = %x\r\n",sda_gyro[2]);
//	lc_printf("GYH = %x\r\n",sda_gyro[3]);
//	lc_printf("GZL = %x\r\n",sda_gyro[4]);
//	lc_printf("GZH = %x\r\n",sda_gyro[5]);
//
//	#endif

    // 计算 GX, GY 和 GZ
    float GX = (float)(((sda_gyro[1] << 8) | sda_gyro[0]) / 32768.0f * 2000.0f);
    if (GX > 2000.0)
    {
        GX -= 4000.0;
    }
    else if (GX < -2000.0)
    {
        GX += 4000.0;
    }
    float GY = (float)(((sda_gyro[3] << 8) | sda_gyro[2]) / 32768.0f * 2000.0f);
    if (GY > 2000.0)
    {
        GY -= 4000.0;
    }
    else if (GY < -2000.0)
    {
        GY += 4000.0;
    }
    float GZ = (float)(((sda_gyro[5] << 8) | sda_gyro[4]) / 32768.0f * 2000.0f);
    if (GZ > 2000.0)
    {
        GZ -= 4000.0;
    }
    else if (GZ < -2000.0)
    {
        GZ += 4000.0;
    }

    // 将计算结果保存到结构体中
    Data->gx = GX;
    Data->gy = GY;
    Data->gz = GZ;
}

