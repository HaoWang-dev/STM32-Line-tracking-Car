#ifndef JY61P_H_
#define JY61P_H_


#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <main.h>
#include "delay.h"
#include "OLED.h"

// 调试开关
#define GYRO_DEBUG	0


// 定义一个结构体来存储
typedef struct {
    float x;
    float y;
    float z;
    float ax;
    float ay;
    float az;
    float gx;
    float gy;
    float gz;
} Gyro_Struct;


// 模块地址
#define	IIC_ADDR		0x50
// 航向角地址
#define YAW_REG_ADDR	0x3F
// 寄存器解锁
#define UN_REG			0x69
// 保存寄存器
#define SAVE_REG		0x00
// 角度参考寄存器
#define ANGLE_REFER_REG	0x01

/* SDA输出模式配置 (开漏输出，100MHz) */
#define SDA_OUT()	do { \
							GPIO_InitTypeDef GPIO_InitStruct = {0}; \
							GPIO_InitStruct.Pin = JY61P_SDA_Pin; \
							GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD; \
							GPIO_InitStruct.Pull = GPIO_PULLUP; \
							GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH; \
							HAL_GPIO_Init(JY61P_SDA_GPIO_Port, &GPIO_InitStruct); \
						} while(0)


/* SDA输入模式配置 (浮空输入) */
#define SDA_IN()	do { \
							GPIO_InitTypeDef GPIO_InitStruct = {0}; \
							GPIO_InitStruct.Pin = JY61P_SDA_Pin; \
							GPIO_InitStruct.Mode = GPIO_MODE_INPUT; \
							GPIO_InitStruct.Pull = GPIO_PULLUP; \
							HAL_GPIO_Init(JY61P_SDA_GPIO_Port, &GPIO_InitStruct); \
						} while(0)


#define SCL(BIT)  (BIT ? HAL_GPIO_WritePin(JY61P_SCL_GPIO_Port, JY61P_SCL_Pin, GPIO_PIN_SET) \
                    : HAL_GPIO_WritePin(JY61P_SCL_GPIO_Port, JY61P_SCL_Pin, GPIO_PIN_RESET))
#define SDA(BIT)  (BIT ? HAL_GPIO_WritePin(JY61P_SDA_GPIO_Port, JY61P_SDA_Pin, GPIO_PIN_SET) \
                    : HAL_GPIO_WritePin(JY61P_SDA_GPIO_Port, JY61P_SDA_Pin, GPIO_PIN_RESET))
#define SDA_GET()  (HAL_GPIO_ReadPin(JY61P_SDA_GPIO_Port, JY61P_SDA_Pin) == GPIO_PIN_SET ? 1 : 0)


void jy61pInit(void);
uint8_t readDataJy61p(uint8_t dev, uint8_t reg, uint8_t *data, uint32_t length);
uint8_t writeDataJy61p(uint8_t dev, uint8_t reg, uint8_t* data, uint32_t length);
void get_angle(Gyro_Struct* Data);
void get_acc(Gyro_Struct* Data);
void get_gyro(Gyro_Struct* Data);




#endif /* JY61P_H_ */
