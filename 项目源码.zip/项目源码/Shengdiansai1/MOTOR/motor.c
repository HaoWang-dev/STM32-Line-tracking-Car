#include "motor.h"

//左电机参数设置函数
void LSET(_Motor* motor)
{
	// 设置电机方向
	switch(motor-> motor_movement)
	{
		case Motor_Forward:
			HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN2_Pin,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN1_Pin,GPIO_PIN_SET);
			break;
		case Motor_Reverse:
			HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN2_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN1_Pin,GPIO_PIN_RESET);
			break;
		case Motor_Waiting:
			HAL_GPIO_WritePin(AIN1_GPIO_Port,AIN1_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(AIN2_GPIO_Port,AIN2_Pin,GPIO_PIN_SET);
			break;
	}
	// 设置电机速度
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, motor -> motor_speed);
}

// 右电机参数设置函数
void RSET(_Motor* motor)
{
	// 设置电机方向
	switch(motor-> motor_movement)
	{
		case Motor_Forward:
			HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_RESET);
			HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_SET);
			break;
		case Motor_Reverse:
			HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_RESET);
			break;
		case Motor_Waiting:
			HAL_GPIO_WritePin(BIN1_GPIO_Port,BIN1_Pin,GPIO_PIN_SET);
			HAL_GPIO_WritePin(BIN2_GPIO_Port,BIN2_Pin,GPIO_PIN_SET);
			break;
	}
	// 设置电机速度
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_2, motor -> motor_speed);

}

// 左电机控制函数
void Motor_Left(_Motor* motor, float speed)
{
	// 设置电机速度
	if(speed > 0)
	{
		motor->motor_movement = Motor_Forward;
		motor->motor_speed = fabsf(speed);
	}
	else if(speed < 0)
	{
		motor->motor_movement = Motor_Reverse;
		motor->motor_speed = fabsf(speed);
	}
	else
	{
		motor->motor_movement = Motor_Waiting;
		motor->motor_speed = fabsf(speed);
	}
	// 执行电机设置函数
	LSET(motor);
}


// 右电机控制函数
void Motor_Right(_Motor* motor, float speed)
{
	// 设置电机速度
	if(speed > 0)
	{
		motor->motor_movement = Motor_Forward;
		motor->motor_speed = fabsf(speed);
	}
	else if(speed < 0)
	{
		motor->motor_movement = Motor_Reverse;
		motor->motor_speed = fabsf(speed);
	}
	else
	{
		motor->motor_movement = Motor_Waiting;
		motor->motor_speed = fabsf(speed);
	}
	// 执行电机设置函数
	RSET(motor);
}

