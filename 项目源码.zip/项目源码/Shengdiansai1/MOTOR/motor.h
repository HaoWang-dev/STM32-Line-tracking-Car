#ifndef MOTOR_H_
#define MOTOR_H_

#include "stm32f4xx_hal.h"
#include <math.h>
#include <main.h>
#include "tim.h"

#define 	LEFT_MOTOR 		'L'
#define 	RIGHT_MOTOR 	'R'

// 定义名为Motor_Movement的枚举类型
// 用于定义小车动作
typedef enum
{
	Motor_Forward,
	Motor_Reverse,
	Motor_Waiting
}Motor_Movement;


// 定义名为_Motor的电机结构体类型
typedef struct
{
	Motor_Movement motor_movement;	// 电机状态
	float motor_speed;				// 电机速度
}_Motor;


// 左电机参数设置函数
void LSET(_Motor* motor);
// 右电机参数设置函数
void RSET(_Motor* motor);
// 左电机控制函数
void Motor_Left(_Motor* motor, float speed);
// 右电机控制函数
void Motor_Right(_Motor* motor, float speed);

#endif /* MOTOR_H_ */
