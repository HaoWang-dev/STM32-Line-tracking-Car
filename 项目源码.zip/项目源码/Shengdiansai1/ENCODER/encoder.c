#include"encoder.h"

void GET_NUM(void)
{
	encoder_counter1 = -(int16_t) __HAL_TIM_GET_COUNTER(&ENCODER_1_HANDLE);
	encoder_counter2 = (int16_t) __HAL_TIM_GET_COUNTER(&ENCODER_2_HANDLE);

	__HAL_TIM_SET_COUNTER(&ENCODER_1_HANDLE, 0);
	__HAL_TIM_SET_COUNTER(&ENCODER_2_HANDLE, 0);
}
