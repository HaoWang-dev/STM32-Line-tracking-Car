#ifndef ENCODER_ENCODER_H_
#define ENCODER_ENCODER_H_

#include "tim.h"

extern TIM_HandleTypeDef htim4;
extern TIM_HandleTypeDef htim5;

extern int16_t encoder_counter1;
extern int16_t encoder_counter2;

#define		ENCODER_1_HANDLE	htim4
#define		ENCODER_2_HANDLE	htim5

void GET_NUM(void);

#endif /* ENCODER_ENCODER_H_ */
