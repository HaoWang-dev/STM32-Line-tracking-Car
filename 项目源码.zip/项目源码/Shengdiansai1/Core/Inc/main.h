/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define GW1_Pin GPIO_PIN_2
#define GW1_GPIO_Port GPIOE
#define OLED_SCL_Pin GPIO_PIN_0
#define OLED_SCL_GPIO_Port GPIOC
#define OLED_SDA_Pin GPIO_PIN_1
#define OLED_SDA_GPIO_Port GPIOC
#define A2_Pin GPIO_PIN_0
#define A2_GPIO_Port GPIOA
#define B2_Pin GPIO_PIN_1
#define B2_GPIO_Port GPIOA
#define PWMA_Pin GPIO_PIN_6
#define PWMA_GPIO_Port GPIOA
#define PWMB_Pin GPIO_PIN_7
#define PWMB_GPIO_Port GPIOA
#define AIN2_Pin GPIO_PIN_0
#define AIN2_GPIO_Port GPIOB
#define AIN1_Pin GPIO_PIN_1
#define AIN1_GPIO_Port GPIOB
#define BIN2_Pin GPIO_PIN_7
#define BIN2_GPIO_Port GPIOE
#define BIN1_Pin GPIO_PIN_8
#define BIN1_GPIO_Port GPIOE
#define KEY1_Pin GPIO_PIN_10
#define KEY1_GPIO_Port GPIOB
#define KEY1_EXTI_IRQn EXTI15_10_IRQn
#define KEY2_Pin GPIO_PIN_11
#define KEY2_GPIO_Port GPIOB
#define KEY2_EXTI_IRQn EXTI15_10_IRQn
#define KEY3_Pin GPIO_PIN_13
#define KEY3_GPIO_Port GPIOB
#define KEY3_EXTI_IRQn EXTI15_10_IRQn
#define KEY4_Pin GPIO_PIN_15
#define KEY4_GPIO_Port GPIOB
#define KEY4_EXTI_IRQn EXTI15_10_IRQn
#define GW2_Pin GPIO_PIN_9
#define GW2_GPIO_Port GPIOD
#define GW4_Pin GPIO_PIN_10
#define GW4_GPIO_Port GPIOD
#define GW5_Pin GPIO_PIN_11
#define GW5_GPIO_Port GPIOD
#define B1_Pin GPIO_PIN_12
#define B1_GPIO_Port GPIOD
#define A1_Pin GPIO_PIN_13
#define A1_GPIO_Port GPIOD
#define GW7_Pin GPIO_PIN_15
#define GW7_GPIO_Port GPIOD
#define Buzzer_Pin GPIO_PIN_0
#define Buzzer_GPIO_Port GPIOD
#define O1_Pin GPIO_PIN_3
#define O1_GPIO_Port GPIOD
#define O1_EXTI_IRQn EXTI3_IRQn
#define GW8_Pin GPIO_PIN_5
#define GW8_GPIO_Port GPIOD
#define GW6_Pin GPIO_PIN_7
#define GW6_GPIO_Port GPIOD
#define JY61P_SCL_Pin GPIO_PIN_6
#define JY61P_SCL_GPIO_Port GPIOB
#define JY61P_SDA_Pin GPIO_PIN_7
#define JY61P_SDA_GPIO_Port GPIOB
#define GW3_Pin GPIO_PIN_0
#define GW3_GPIO_Port GPIOE

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
