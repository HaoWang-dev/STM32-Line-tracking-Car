/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "delay.h"
#include "encoder.h"
#include "gw.h"
#include "jy61p.h"
#include "motor.h"
#include "OLED.h"
#include "pid.h"
#include "led.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//定义蜂鸣器函数宏定义
#define		_BUZZER_ON()		HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_RESET)
#define		_BUZZER_OFF()		HAL_GPIO_WritePin(Buzzer_GPIO_Port, Buzzer_Pin, GPIO_PIN_SET)

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

//编码器读数变量
int16_t encoder_counter1 = 0;
int16_t encoder_counter2 = 0;

//电机结构体变量
_Motor MOTOR_LEFT = {.motor_movement = Motor_Waiting, .motor_speed = 0.0};
_Motor MOTOR_RIGHT = {.motor_movement = Motor_Waiting, .motor_speed = 0.0};

//定义电机结构体
Gyro_Struct JY61P_Data;

//定义任务标志位
uint8_t task_flag = 0;

//定义圈数判断标志位
uint8_t cycle_flag = 0;

//定义转向环PID结构体
PID Turn_PID;

//定义感为数据读取数值
uint8_t Parallel = 0;
char gw_str_Parallel[9];

//定义目标圈数和实际圈数
volatile uint8_t target_cycle = 1;
uint8_t actual_cycle = 0;

//定义一圈的编码数
float encoder_standard = 1560;

//定义小车速度
float speed = 0;

//定义基础PWM
int16_t base_pwm = 0;

//定义差速PWM
int16_t diff_pwm = 0;

//定义左电机PWM
 int16_t left_pwm = 0;

//定义右电机PWM
int16_t right_pwm = 0;

//定义循迹误差权重
int8_t err_weight[8] = {-35, -25, -15, -5, 5, 15, 25, 35};

//避免冲出黑线，定义误差存储变量
float err = 0;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  MX_TIM5_Init();
  MX_USART2_UART_Init();
  MX_TIM6_Init();
  MX_TIM7_Init();
  MX_TIM10_Init();
  MX_TIM11_Init();
  MX_TIM13_Init();
  /* USER CODE BEGIN 2 */

  //开启时钟
  HAL_TIM_Base_Start(&htim3);
  HAL_TIM_Base_Start(&htim4);
  HAL_TIM_Base_Start(&htim5);
  HAL_TIM_Base_Start(&htim6);
  HAL_TIM_Base_Start_IT(&htim7);
  HAL_TIM_Base_Start_IT(&htim10);
  HAL_TIM_Base_Start_IT(&htim11);
  HAL_TIM_Base_Start_IT(&htim13);

  //开启编码器
  HAL_TIM_Encoder_Start(&htim4, TIM_CHANNEL_ALL);
  HAL_TIM_Encoder_Start(&htim5, TIM_CHANNEL_ALL);

  //开启PWM波
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_4);

  //jy61p初始化
  jy61pInit();

  //OLED初始化
  OLED_Init();

  //PID初始化
  PID_Clear(&Turn_PID);
  //因为此项目没有稳态误差，所以不需要I项调控
  PID_Init(&Turn_PID, 2.2, 0, 1.5, 500, 1000);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  //以下是OLED显示部分
	  OLED_ShowString(30, 0, "OLED is OK", 6);

	  OLED_ShowFloatNum(0, 10, encoder_counter1, 3, 2, 6);
	  OLED_ShowFloatNum(70, 10, encoder_counter2, 3, 2, 6);

	  OLED_ShowString(0, 20, gw_str_Parallel, 6);

	  OLED_ShowFloatNum(70, 20, JY61P_Data.z, 3, 2, 6);

	  OLED_ShowNum(0, 30, target_cycle, 2, 6);
	  OLED_ShowNum(20, 30, actual_cycle, 2, 6);

	  OLED_ShowFloatNum(50, 30, speed, 3, 3, 6);

	  OLED_ShowFloatNum(0, 40, Turn_PID.kp, 2, 2, 6);
	  OLED_ShowFloatNum(40, 40, Turn_PID.ki, 2, 2, 6);
	  OLED_ShowFloatNum(80, 40, Turn_PID.kd, 2, 2, 6);

	  OLED_ShowFloatNum(0, 50, err, 3, 2, 6);

	  OLED_ShowNum(50, 50, task_flag, 2, 6);

	  //OLED必须使用此函数
	  OLED_Update();

	  //经过实测，当误差为正时，左轮加速，右轮减速
	  //故，8路灰度循迹应该右半为正，左半为副
	  base_pwm = 1000;


	  //当未达到圈数时
	  if(actual_cycle < target_cycle)
	  {
		  //任务1，可设圈数，停车避障
		  if(1 == task_flag)
		  {


			  if((JY61P_Data.z >= 75) && (JY61P_Data.z <= 105))
			  {
				  cycle_flag = 1;
			  }
			  if(((JY61P_Data.z >= -15) && (JY61P_Data.z <= 15)) && (1 == cycle_flag))
			  {
				  actual_cycle += 1;
				  cycle_flag = 0;
			  }
		  }
		  //光电开关检测到障碍物，停车避障
		  if(12 == task_flag)
		  {
			  //关闭PID调控
			  __HAL_TIM_DISABLE_IT(&htim11, TIM_IT_UPDATE);

			  //停车
			  Motor_Left(&MOTOR_LEFT, 0);
			  Motor_Right(&MOTOR_RIGHT, 0);

			  //声光提示
			  _BUZZER_ON();
			  LED(300);
			  HAL_Delay(1000);
			  _BUZZER_OFF();
			  LED(0);

			  task_flag = 0;
		  }

		  //任务1经过测试没有问题

		  //任务2，可设圈数，障碍绕行
		  if(2 == task_flag)
		  {
			  base_pwm = 200;

			  if((JY61P_Data.z >= 75) && (JY61P_Data.z <= 105))
			  {
				  cycle_flag = 1;
			  }
			  if(((JY61P_Data.z >= -15) && (JY61P_Data.z <= 15)) && (1 == cycle_flag))
			  {
				  actual_cycle += 1;
				  cycle_flag = 0;
			  }
		  }
		  //光电开关检测到障碍，开环绕行
		  if(22 == task_flag)
		  {
			  //关闭PID调控
			  __HAL_TIM_DISABLE_IT(&htim11, TIM_IT_UPDATE);

			  //开始左转
			  Motor_Left(&MOTOR_LEFT, 100);
			  Motor_Right(&MOTOR_RIGHT, 320);

			  HAL_Delay(380);

			  Motor_Left(&MOTOR_LEFT, 460);
			  Motor_Right(&MOTOR_RIGHT, 150);

			  HAL_Delay(520);

			  //转回线路
			  Motor_Left(&MOTOR_LEFT, 300);
			  Motor_Right(&MOTOR_RIGHT, 180);
			  task_flag = 23;
		  }

		  if(23 == task_flag)
		  {
			  //车回到线上
			  if(!(Parallel & (1 << 0)))
			  {
				  //清除干扰数据
				  PID_Clear(&Turn_PID);

				  //开启PID调控
				  __HAL_TIM_ENABLE_IT(&htim11, TIM_IT_UPDATE);

				  //回到PID调控任务
				  task_flag = 2;
			  }
		  }
	  }
	  //圈数以达到设定圈数
	  else
	  {
		  //关闭PID调控
		  __HAL_TIM_DISABLE_IT(&htim11, TIM_IT_UPDATE);

		  //停车
		  Motor_Left(&MOTOR_LEFT, 0);
		  Motor_Right(&MOTOR_RIGHT, 0);
	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 100;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */


//定时器更新中断函数
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	//读取编码器脉冲数，计算圈数
	if(htim->Instance == TIM7)
	{
		GET_NUM();

		speed = (((encoder_counter1 + encoder_counter2) / 2) / encoder_standard * 2 * 3.14 * 24) / 0.02 / 33;
	}
	//读取灰度传感器的数值
	if(htim->Instance == TIM10)
	{
		Parallel = scan_gpio_pin_Parallel();

		for(uint8_t i = 0; i < 8; i++)
		{
			gw_str_Parallel[i] = (Parallel & (1 << (7 - i))) ? '1': '0';
		}

		gw_str_Parallel[8] = '\0';
	}
	//计算PID，卡转向环PID
	if(htim->Instance == TIM11)
	{
		err = calc_error(gw_str_Parallel, err_weight);
		PID_Single_err(&Turn_PID, err);

		diff_pwm = Turn_PID.output;

		left_pwm = base_pwm + diff_pwm;
		right_pwm = base_pwm - diff_pwm;

		LIMIT(left_pwm, -1000, 800);
		LIMIT(right_pwm, -1000, 800);

		Motor_Left(&MOTOR_LEFT, left_pwm);
		Motor_Right(&MOTOR_RIGHT, right_pwm);
	}
	//读取JY61P角度
	if(htim->Instance == TIM13)
	{
		get_angle(&JY61P_Data);
	}
}


//外部中断回调函数
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	switch(GPIO_Pin)
	{
		//四个按键
		case KEY1_Pin:
			task_flag = 1;
			break;
		case KEY2_Pin:
			task_flag = 2;
			break;
		case KEY3_Pin:
			//Turn_PID.kp += 0.1;
			target_cycle += 1;
			break;
		case KEY4_Pin:
			Turn_PID.kd += 0.1;
			break;
		//光电开关的特性可以让他当外部中断
		case O1_Pin:
			if(1 == task_flag)
			{
				task_flag = 12;
			}
			if(2 == task_flag)
			{
				task_flag = 22;
			}
			break;
		default:
			task_flag = 0;
	}
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
