#ifndef LED_H_
#define LED_H_


#include "tim.h"

//函数定义
//LED开关
void LED(uint16_t weight);
//呼吸灯
void LED_Breathing();



#endif /* LED_H_ */
