#include "led.h"


void LED(uint16_t weight)
{
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, weight);
}


void LED_Breathing()
{
	static uint16_t weight = 0;
	static int8_t step = 40;

	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_4, weight);

	weight += step;

	if(weight >= 1000 || weight <=0)
	{
		step = -step;
	}

	HAL_Delay(10);
}
